/* Only the current page URL goes to loopback. No DOM, Cookie or site logic. */
const MENU_ID = "send-to-mangareader";
const COOLDOWN_MS = 3000;
let sending = false;
let recent = null;

async function showResult(tabId, text, title, failed = false) {
  // Closing the tab must not turn an accepted request into a transport failure.
  try {
    await chrome.action.setBadgeBackgroundColor({ color: failed ? "#ad4354" : "#365cbf", tabId });
    await chrome.action.setBadgeText({ text, tabId });
    await chrome.action.setTitle({ title, tabId });
  } catch (_) { /* Tab may have closed. */ }
  try {
    await chrome.storage.session.set({ lastResult: title });
  } catch (_) { /* The badge/title remain usable if session storage fails. */ }
}

async function sendCurrentTab(tab) {
  if (sending) return; // Set synchronously before any await; shared by both entry points.
  sending = true;
  const tabId = tab?.id;
  try {
    let url;
    try { url = new URL(tab?.url || ""); } catch (_) {
      throw new Error("現在のタブURLを取得できません。作品ページを開き直してください");
    }
    if (!["http:", "https:"].includes(url.protocol)) {
      throw new Error("未対応URLです。HTTP/HTTPSの作品ページを開いてください");
    }
    if (url.username || url.password || url.href.length > 8192) {
      throw new Error("認証情報入りURL、または長すぎるURLは送信できません");
    }
    const { token, port = 18765 } = await chrome.storage.local.get(["token", "port"]);
    if (typeof token !== "string" || !token.trim()) {
      await showResult(tabId, "!", "接続トークン未設定 — MangaReaderの設定からコピーしてください", true);
      await chrome.runtime.openOptionsPage();
      return;
    }
    // Never interpolate an unchecked value into the loopback endpoint.
    if (!Number.isInteger(port) || port < 1024 || port > 65535) {
      throw new Error("接続ポートが不正です。拡張の設定を確認してください");
    }
    try {
      const stored = await chrome.storage.session.get("recentSend");
      recent = stored.recentSend || null;
    } catch (_) { /* In-memory cooldown plus receiver-side deduplication remain. */ }
    if (recent?.url === url.href && recent.port === port && recent.until > Date.now()) {
      await showResult(tabId, "OK", "送信済み（重複送信を防止）— MangaReaderで取得結果を確認してください");
      return;
    }
    await showResult(tabId, "…", "MangaReaderへ送信中…");
    let response;
    try {
      response = await fetch(`http://127.0.0.1:${port}/import`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-MangaReader-Token": token.trim() },
        body: JSON.stringify({ url: url.href }),
        credentials: "omit",
        redirect: "error",
        referrerPolicy: "no-referrer",
        cache: "no-store",
        signal: AbortSignal.timeout(5000),
      });
    } catch (_) {
      throw new Error("MangaReaderに接続できません。アプリを起動し、受信ポートを確認してください（応答なし／タイムアウト／リダイレクト拒否）");
    }
    if (response.status === 401) throw new Error("接続トークンが一致しません。MangaReaderの設定から再コピーしてください");
    if (response.status === 409) throw new Error("MangaReaderは取得処理中です。プレビュー完了後に再試行してください");
    if (response.status === 503) throw new Error("MangaReaderの受信処理を利用できません。アプリの状態を確認してください");
    if (!response.ok) throw new Error(`MangaReaderが送信を拒否しました（HTTP ${response.status}）`);
    let result;
    try { result = await response.json(); } catch (_) {
      throw new Error("受信確認が不正です。MangaReaderの接続ポートを確認してください");
    }
    if (response.status !== 202 || result?.accepted !== true) {
      throw new Error("受信確認が不正です。MangaReaderの接続ポートを確認してください");
    }
    recent = { url: url.href, port, until: Date.now() + COOLDOWN_MS };
    try { await chrome.storage.session.set({ recentSend: recent }); } catch (_) { /* See above. */ }
    await showResult(tabId, "OK", result.duplicate
      ? "送信済み（重複送信を防止）— MangaReaderで取得結果を確認してください"
      : "受信完了 — MangaReaderで取得・プレビューを確認してください。保存はアプリ内で行います");
  } catch (error) {
    await showResult(tabId, "!", `送信失敗: ${error.message}`, true);
  } finally {
    sending = false;
  }
}

chrome.action.onClicked.addListener(sendCurrentTab);
chrome.contextMenus.onClicked.addListener((info, tab) => {
  // Deliberately ignore linkUrl/srcUrl/frameUrl: send the current top-level page.
  if (info.menuItemId === MENU_ID) return sendCurrentTab(tab);
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_ID, title: "MangaReaderに送る",
      contexts: ["page", "selection", "image", "link"],
      documentUrlPatterns: ["http://*/*", "https://*/*"],
    });
  });
});
