async function loadSettings() {
  const { token = "", port = 18765 } = await chrome.storage.local.get(["token", "port"]);
  document.getElementById("token").value = token;
  document.getElementById("port").value = port;
  const { lastResult = "まだ送信していません" } = await chrome.storage.session.get("lastResult");
  document.getElementById("last-result").textContent = `前回結果: ${lastResult}`;
}

document.getElementById("settings").addEventListener("submit", async (event) => {
  event.preventDefault();
  const token = document.getElementById("token").value.trim();
  const port = Number(document.getElementById("port").value);
  const status = document.getElementById("status");
  if (!token || !Number.isInteger(port) || port < 1024 || port > 65535) {
    status.textContent = "接続トークンと有効なポートを入力してください。";
    return;
  }
  try {
    await chrome.storage.local.set({ token, port });
    await chrome.storage.session.remove("recentSend");
    status.textContent = "保存しました。作品ページで拡張アイコンを押してください。";
  } catch (error) {
    status.textContent = `保存できませんでした: ${error.message}`;
  }
});

loadSettings().catch((error) => {
  document.getElementById("status").textContent = `設定を読み込めませんでした: ${error.message}`;
});
