# MangaReader V2

Windows向け、Python + PySide6 + SQLite + Pillowのローカル漫画ライブラリです。
サイト固有HTML・サイト専用Adapterは含みません。

## 起動・旧版からの移行

**GitHubが唯一のコード正本です。配布構成は完全ポータブルの1種類だけです。**
Windows ZIPを展開し、`MangaReader/MangaReaderV2.exe` を起動してください。PythonやPowerShellの操作は不要です。

```text
MangaReader/
├─ MangaReaderV2.exe
├─ data/
├─ local_adapters/
├─ extension/
└─ _internal/ など実行に必要なファイル
```

保存先は常にEXE横です。フォルダ一式をC/D/外付け等へ移動できます。
`portable.flag` は不要です。通常運用で `%LOCALAPPDATA%` や別保存先へ切り替わることはありません。
書き込めないフォルダに置いた場合は明示的に停止し、別の場所へ黙って保存しません。

初回起動では **「旧MangaReaderから移行」か「新しく使い始める」だけを選択** します。
旧版を使っていた場合は、使用中の `manga` フォルダを1回選択してください。
PC内を自動探索したり、複数の旧コピーから推測したりしません。
選択した旧版から **data・local_adapters・DB内の設定をコピー → 検証 → 新版へ配置** します。
ファイル単位の手動コピーは不要です。旧MangaReaderは先に終了してください。

- お気に入り、読書位置、接続トークン、ジョブ、途中保存、バックアップを保持します。
- 旧フォルダは自動削除しません。検証PASS後だけ削除候補として記録しますが、削除操作は行いません。
- 移行先にデータがあれば上書き・自動マージしません。
- 保存画像が無い・不完全な作品は、その作品だけ新版コピーからスキップして起動します。旧版のデータは変更しません。
- SQLite自体の破損、不正なリンク、移行先競合など安全性を保証できない場合だけ移行を停止します。
- 旧DBが古い絶対パスを持っていても、選択した旧ライブラリ内の検証済み作品へ安全に付け替えます。
- 実サイトAdapterと利用者のdataはGitHubや配布ZIPへ含めません。

同じライブラリの多重起動を防止します。URL受信は標準 `127.0.0.1:18765` です。
ブラウザ拡張の初回登録はブラウザ側で必要です（下記参照）。既存接続トークンはコピーで保持します。
設定画面には実サイトAdapterをファイル名ごとに `PASS / FAIL` 表示し、読み込み失敗理由もそのまま表示します。

## 取り込みと閲覧

1. 「フォルダー」から画像フォルダー、または `.manga.json` を選択します。
2. 作品詳細でメタデータと1ページ目のプレビューを確認します。
3. 「保存」で全ページを取り込みます。ダウンロード画面に進捗と失敗理由が表示されます。
4. 全画像の検証が成功すると、サムネイル付きでライブラリに表示されます。
5. 「読む」でViewerを開きます。前／次ボタンまたは左右キーで移動、Escで詳細に戻ります。

ライブラリは新着順です。「お気に入りのみ」で絞り込めます。
詳細の作者・サークル・内容タグをクリックすると、その値でライブラリを絞り込みます。
Fit to screenはページ移動後・アプリ再起動後も保持し、読書位置は作品ごとに保存します。
ゴミ箱は論理削除です。作品詳細から復元できます。ファイルの完全削除は行いません。

サンプル画像を生成して、サイトやAdapterなしで操作確認できます。

```powershell
.\.venv\Scripts\python.exe tools/create_demo.py .\data\sample-input --pages 62
```

「作品JSONを取り込む」で `data/sample-input/sample.manga.json` を選択します。
サンプルは幾何学図形のオリジナル画像です。

## 差分アップデート

初回だけフル版が必要です。以後、通常のコード修正ではGitHub Actionsが
`MangaReader-Patch` を生成します。フル版の `_internal/` を毎回取り直す必要はありません。

1. GitHubから `MangaReader-Patch` のZIPを取得します。
2. MangaReaderの「設定」→「更新パッチを適用」で、そのZIPを選択します。
3. SHA-256・manifest・保存先を検証後、MangaReaderが安全に終了して更新・再起動します。

差分パッチが変更できるのは `MangaReaderV2.exe`、`README.md`、`version.json`、
`extension/` だけです。**`data/` と `local_adapters/` は更新対象外です。**
更新前ファイルは `data/backups/updates/` へ退避します。
Python / Qt / PyInstallerランタイム構成が変わる場合は `runtime_abi` が変わり、
その更新だけはパッチを拒否してフル版を要求します。

## Chrome / Edge拡張

1. Chromeの拡張機能管理、またはEdgeの拡張機能管理で開発者モードを有効にします。
2. 「パッケージ化されていない拡張機能を読み込む」で `extension/` を選択します。
3. MangaReaderの「設定」で接続トークンをコピーします。
4. 拡張機能のオプションにトークンとポートを保存します。
5. 拡張をツールバーへ固定し、HTTP/HTTPS作品ページでアイコンを1回押します。
   右クリック「MangaReaderに送る」でも同じ操作になります（画像・リンク先ではなく現在ページのURL）。
6. MangaReaderが自動で作品を取得し、詳細／1ページ目プレビューへ移動します。
   確認後にアプリ内の「保存」を押してください。

更新済みの拡張は `chrome://extensions`／`edge://extensions` の再読み込みボタンで反映します。
MangaReaderも再起動してください。既存の接続トークン設定は保持されます。

`OK` バッジは受信確認です。Adapterの取得結果・プレビューはアプリ側で確認し、
保存はアプリの「保存」ボタンで実行します。未対応URLはアプリ側にエラーが表示されます。
`!` が出たらアイコンにマウスを重ねると理由を表示します。拡張の設定画面にも前回結果を表示します。
未起動・タイムアウト、トークン不一致、取得処理中、ポート不正を区別して案内します。
HTTP/HTTPS以外のURLは拡張で拒否します。サイト用Adapterがない場合はMangaReaderの詳細画面に
取得失敗を表示し、古い作品のプレビュー／保存ボタンを残しません。

送信中の連打は無視し、受信済みの同じURLは3秒間再送しません。受信側も重複を抑止するため、
Chrome／Edgeから同時に送っても解析は1回です。意図的な再試行は3秒後に行えます。

送信先は `http://127.0.0.1:<設定ポート>/import` のみ（標準18765）。
外部へのリダイレクトを拒否し、Cookie・Refererを送信しません。
接続トークンはブラウザ内のlocal領域に保持し、同期ストレージや外部サービスは使いません。
拡張はページ本文・Cookie・Refererを収集しません。初期状態にはHTTPサイトを処理する
Adapterがないため、独自のローカルAdapterを配置する必要があります。

## Adapter API

詳しい契約と作品JSON形式は [docs/adapter-api.md](docs/adapter-api.md) を参照してください。
`local_adapters/` は `.gitignore` 対象です。サイト固有実装を本体へ追加しない構成です。

## ローカルAdapter診断

`local_adapters/example_adapter.py.template` を `my_adapter.py` などへコピーし、
3メソッドをローカルで実装してください。テンプレート自体は読み込まれません。
Git管理するのは汎用テンプレートのみで、Adapter本体・サブフォルダーは除外されます。

セットアップ済みの `.venv` で、リポジトリのルートから次の1コマンドを実行します。

```powershell
.\tools\test_local_adapter.ps1 -Url "https://example.com/work"
```

全メタデータ・`can_handle`・`images_found` と失敗理由をJSON表示します。
件数不一致・重複・不正メタデータ・読み込み失敗はFAILです。
`first_page_image`、先頭、末尾をそれぞれ実際にHTTP取得しPillowで検証します。
PASSは終了コード0、FAILは1（引数エラーは2）。DB・作品保存先には書き込みません。
先頭と末尾だけのスモークテストなので、中間ページの取得成功は保証しません。
未対応URLや未実装テンプレートだけの状態はFAILであり、実サイト成功扱いしません。
Cookie・独自Refererが必要なサイトは現行本体のHTTP取得と同様に失敗します。

別のPython／Adapterフォルダーは `-Python`／`-AdaptersDir` で指定できます。
Pythonから直接実行する場合:

```powershell
.\.venv\Scripts\python.exe -m mangareader.adapter_diagnostics --url "https://example.com/work" --adapters-dir .\local_adapters
```

## 保存と再開

- SQLiteにはメタデータ、ファイルパス、お気に入り、読書位置、ジョブ、設定を保存します。
- 画像は `books/<作品ID>/` に保存し、DBには格納しません。
- 一時保存は `.incomplete/<作品ID>/`。Pillowで全画像を開き、SHA-256を検証してから
  同一ボリューム内で正式フォルダーに移動し、ライブラリへ登録します。
- エラー時は未完成のまま保持します。ダウンロード画面で失敗・中断ジョブを選び
  「再試行・再開」を押すと、検証できたページだけを再利用します。
- 終了時は現在の画像処理が終わるのを待って中断し、次回起動時に再開できます。
  正式フォルダー移動後・DB登録前に終了した場合も再試行で復旧できます。
- Pillowで実形式を検証し、JPEG→`.jpg`、PNG→`.png`、WebP→`.webp`、GIF→`.gif`、
  BMP→`.bmp`、TIFF→`.tiff` の連番で保存します。画像バイト列は変換しません。
  旧 `.img` 保存・途中保存も読み込み／再開できます。表紙は `thumbnail.jpg` です。

## テスト

```powershell
.\.venv\Scripts\python.exe -m pytest -q
node --test tests/extension.test.cjs
```

Pythonテストは保存・画像破損・再開・クラッシュ復旧・HTTP通信・SQLite・Adapter読み込み・
Qtの画面操作を含みます。UIテストはoffscreenで実行し、`test-artifacts/` に画面画像を出力します。
Node.js 20以降のテストは拡張APIのモックと実際のPython localhost受信を接続します。
Chrome/Edgeへ拡張を読み込んだ実機クリック検証は別途必要です。

設計と初版の制約は [docs/architecture.md](docs/architecture.md) を参照してください。



## 安全確認・バックアップ

Windowsではリポジトリ内の `tools\SAFE_CHECK_AND_BACKUP.bat` をダブルクリックすると、
保存済み作品を深く検証してから、SQLite DB・設定・ローカルAdapterを
`data\backups\metadata-*.zip` へ退避します。漫画画像そのものはZIPへ入れません。
DB migrationが必要な場合は、アプリ側でも変換前SQLiteを `data\backups\` へ自動保存します。

バックアップZIPには接続トークンとローカルAdapterコードが含まれるため、第三者へ共有しないでください。

変更後の総合確認は `tools\VALIDATE.bat` をダブルクリックします。
PythonテストとNode.js拡張テストを順番に実行し、どちらも成功した場合だけ `RESULT=PASS` になります。


## 開発・検証

設計は [docs/architecture.md](docs/architecture.md)、Adapter契約は [docs/adapter-api.md](docs/adapter-api.md)、
CI・Windowsビルド・リリース整理・残る実機確認は [docs/development.md](docs/development.md) に集約しています。
